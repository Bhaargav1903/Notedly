# JavaScript Everywhere API Solutions

> API code example solutions for JavaScript Everywhere by Adam Scott, published by O'Reilly Media

This directory contains chapter by chapter solutions for the code examples found in the book. For the starter project, visit the `/src` directory and for the final project, visit `/final`.

## Getting Help

The best place to get help is our Spectrum channel, [spectrum.chat/jseverywhere](https://spectrum.chat/jseverywhere).
